from wylib.models.Sentinel2Image import *
from wylib.models.RSImage import *
from wylib.utils import *


class Sentinel2L1CImage(Sentinel2Image):
    def __init__(self, image_dir):
        '''
        初始化Sentinel-2 L1C影像，每个波段图像实例化为RSImage对象
        :param image_dir: Sentinel-2 L1C影像目录
        '''
        super().__init__(image_dir)
        self.B1 = None
        self.B2 = None
        self.B3 = None
        self.B4 = None
        self.B5 = None
        self.B6 = None
        self.B7 = None
        self.B8 = None
        self.B8A = None
        self.B9 = None
        self.B10 = None
        self.B11 = None
        self.B12 = None
        self.load_from_file()

    def load_from_file(self):
        '''
        从文件中读取Sentinel-2 L1C影像
        '''
        root_GRANULE = os.path.join(self.image_dir, "GRANULE")
        path = os.listdir(root_GRANULE)[0]
        path = os.path.join(root_GRANULE, str(path), "IMG_DATA")
        for filewalks in os.walk(path):
            for files in filewalks[2]:
                if files.endswith("B01.jp2"):
                    self.B1 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B02.jp2"):
                    self.B2 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B03.jp2"):
                    self.B3 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B04.jp2"):
                    self.B4 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B05.jp2"):
                    self.B5 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B06.jp2"):
                    self.B6 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B07.jp2"):
                    self.B7 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B08.jp2"):
                    self.B8 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B8A.jp2"):
                    self.B8A = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B09.jp2"):
                    self.B9 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B10.jp2"):
                    self.B10 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B11.jp2"):
                    self.B11 = RSImage(os.path.join(path, files))
                    self.band_count += 1
                if files.endswith("B12.jp2"):
                    self.B12 = RSImage(os.path.join(path, files))
                    self.band_count += 1

    def resample_10m(self, method="bicubic", B10_flag=False):
        '''
        重采样至10米
        :param method: 重采样方法
        :param B10_flag: 是否处理B10
        :return result_image: 重采样后的影像，类型为RSImage对象
        '''
        w_10m, h_10m = self.B2.image_array.shape
        S_20 = np.stack([self.B5.image_array, self.B6.image_array, self.B7.image_array, self.B8A.image_array, self.B11.image_array, self.B12.image_array])
        S_60 = np.stack([self.B1.image_array, self.B9.image_array, self.B10.image_array])
        S_20_resized = image_resize(S_20, w_10m, h_10m, dtype=self.B2.dtype, interpolation_method=RESAMPLE_METHODS[method])
        S_60_resized = image_resize(S_60, w_10m, h_10m, dtype=self.B2.dtype, interpolation_method=RESAMPLE_METHODS[method])

        if B10_flag:
            result_array = np.stack([S_60_resized[0, :, :], self.B2.image_array, self.B3.image_array, self.B4.image_array, S_20_resized[0, :, :],
                             S_20_resized[1, :, :], S_20_resized[2, :, :], self.B8.image_array, S_20_resized[3, :, :], S_60_resized[1, :, :],
                             S_60_resized[2, :, :], S_20_resized[4, :, :], S_20_resized[5, :, :]])
        else:
            result_array = np.stack([S_60_resized[0, :, :], self.B2.image_array, self.B3.image_array, self.B4.image_array, S_20_resized[0, :, :],
                             S_20_resized[1, :, :], S_20_resized[2, :, :], self.B8.image_array, S_20_resized[3, :, :], S_60_resized[1, :, :],
                             S_20_resized[4, :, :], S_20_resized[5, :, :]])

        result_image = RSImage()
        result_image.img_GeoTransform = self.B2.img_GeoTransform
        result_image.img_proj = self.B2.img_proj
        result_image.image_array = result_array
        result_image.column = self.B2.column
        result_image.row = self.B2.row
        result_image.band_count = result_array.shape[0]
        result_image.no_data_value = self.B2.no_data_value
        result_image.dtype = self.B2.dtype

        del S_20, S_60, S_20_resized, S_60_resized, result_array

        return result_image