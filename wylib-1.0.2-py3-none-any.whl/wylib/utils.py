import shutil
import numpy as np
import cv2
from osgeo import gdal
from osgeo import osr
import pandas as pd
import matplotlib.pyplot as plt
import os
import requests
import os
import json
import zipfile
import getpass


def tif_to_jpg(tif_path, jpg_path):
    """
    实现tif转jpg
    :param tif_path:输入路径
    :param jpg_path:输出路径
    """
    filenames = os.listdir(tif_path)
    print(len(filenames))
    for filename in filenames:
        # 输入文件名
        file_path = os.path.join(tif_path, filename)
        tif_img = cv2.imread(file_path, -1)
        # 输出路径
        jpg_to = os.path.join(jpg_path, filename)  # 路径2拼接
        cv2.imwrite(jpg_to.split('.')[0] + ".jpg", tif_img)


def tif_to_png(tif_path, png_path):
    """
    实现tif转png
    :param tif_path: 输入路径
    :param png_path: 输出路径
    """
    filenames = os.listdir(tif_path)
    print(len(filenames))
    for filename in filenames:
        # 输入文件名
        file_path = os.path.join(tif_path, filename)
        tif_img = cv2.imread(file_path, -1)
        # 输出路径
        png_to = os.path.join(png_path, filename)  # 路径2拼接
        cv2.imwrite(png_to.split('.')[0] + ".png", tif_img)


def image_resize(image, height, width, dtype=np.uint16, interpolation_method=cv2.INTER_CUBIC):
    '''
    图像重采样至指定尺寸，可支持多通道、批处理
    :param image: 输入图像，通道在前，批量在最前
    :param height: 重采样目标高度
    :param width: 重采样目标宽度
    :param dtype: 重采样目标类型
    :param interpolation_method: 重采样方法
    :return new_image: 重采样结果
    '''
    if len(image.shape) == 4:
        batch_size, channel, _, _ = image.shape
        new_image = np.zeros((batch_size, channel, height, width), dtype=dtype)
        for batch in range(batch_size):
            for c in range(channel):
                new_image[batch, c, :, :] = cv2.resize(image[batch, c, :, :], (width, height), interpolation=interpolation_method)
        return new_image
    elif len(image.shape) == 3:
        channel, _, _ = image.shape
        new_image = np.zeros((channel, height, width), dtype=dtype)
        for c in range(channel):
            new_image[c, :, :] = cv2.resize(image[c], (width, height), interpolation=interpolation_method)
        return new_image
    else:
        return None


def dms_to_decimal(d, m, s):
    decimal = d + float(m) / 60 + float(s) / 3600
    return round(decimal, 12)


def position_transform_str2num(s):
    '''
    :param s: 字符串经/纬度 ex：39°50'4"
    :return: 浮点数经/纬度
    '''
    result = []
    s_list = s.split("°")
    result.append(s_list[0])
    temp = s_list[1]
    temp = temp.split("'")
    result.append(temp[0])
    temp = temp[1]
    temp = temp.split("\"")
    result.append(temp[0])
    return dms_to_decimal(int(result[0]), int(result[1]), float(result[2]))


def lonlat2imagexy_Sentinel(img_GeoTransform, img_proj, lon, lat):
    prosrs = osr.SpatialReference()
    prosrs.ImportFromWkt(img_proj)
    geosrs = prosrs.CloneGeogCS()

    ct = osr.CoordinateTransformation(geosrs, prosrs)
    coords = ct.TransformPoint(lat, lon)

    projection_coords = coords[:2]
    x = projection_coords[0]
    y = projection_coords[1]
    trans = img_GeoTransform
    a = np.array([[trans[1], trans[2]], [trans[4], trans[5]]])
    b = np.array([x - trans[0], y - trans[3]])
    coords = np.linalg.solve(a, b)

    return int(coords[0]), int(coords[1])


def imagexy2lonlat_Sentinel(img_GeoTransform, img_proj, x, y):
    trans = img_GeoTransform
    col, row = x, y
    px = trans[0] + col * trans[1] + row * trans[2]
    py = trans[3] + col * trans[4] + row * trans[5]

    prosrs = osr.SpatialReference()
    prosrs.ImportFromWkt(img_proj)
    geosrs = prosrs.CloneGeogCS()

    ct = osr.CoordinateTransformation(prosrs, geosrs)
    coords = ct.TransformPoint(px, py)
    return coords[:2]


def lonlat2imagexy(img_GeoTransform, img_proj, lon, lat):
    prosrs = osr.SpatialReference()
    prosrs.ImportFromWkt(img_proj)
    geosrs = prosrs.CloneGeogCS()

    ct = osr.CoordinateTransformation(geosrs, prosrs)
    coords = ct.TransformPoint(lon, lat)

    projection_coords = coords[:2]
    x = projection_coords[0]
    y = projection_coords[1]
    trans = img_GeoTransform
    a = np.array([[trans[1], trans[2]], [trans[4], trans[5]]])
    b = np.array([x - trans[0], y - trans[3]])
    coords = np.linalg.solve(a, b)

    return int(coords[0]), int(coords[1])


def imagexy2lonlat(img_GeoTransform, img_proj, x, y):
    trans = img_GeoTransform
    col, row = x, y
    px = trans[0] + col * trans[1] + row * trans[2]
    py = trans[3] + col * trans[4] + row * trans[5]

    prosrs = osr.SpatialReference()
    prosrs.ImportFromWkt(img_proj)
    geosrs = prosrs.CloneGeogCS()

    ct = osr.CoordinateTransformation(prosrs, geosrs)
    coords = ct.TransformPoint(px, py)
    return coords[:2]


def show_spectra_AWRMMS(inputFolderPath="./Output", delete_index_list=[]):
    '''
    AWRMMS光谱仪测量结果展示，程序结束后可将平均光谱保存在当前目录下
    :param inputFolderPath: 光谱仪配套软件输出结果
    :param delete_index_list: 需要删除的测量记录下标列表
    '''
    fileFolder_name_list = os.listdir(inputFolderPath)      # 输入路径
    result = []
    plt.figure()
    plt.subplot(2, 1, 1)
    for index, fileName in enumerate(fileFolder_name_list):
        filePath = os.path.join(inputFolderPath, fileName, "Rrs_" + fileName + "_OA_1.0nm.txt")
        with open(filePath, 'r') as f:
            data = f.readlines()
        # 327nm - 940nm
        start_row = 19
        matrix_data = []
        for i in range(start_row, start_row + 614):
            matrix_data.append(list(map(float, data[i].split())))
        matrix = np.array(matrix_data)
        # 读取矩阵的mobley列
        f_column = matrix[:, 4]
        if index + 1 not in delete_index_list:
            result.append(f_column.T)
            plt.plot(range(327, 941), f_column, label=str(index + 1))
    plt.ylabel("Rrs (sr^-1)")
    plt.legend()

    mean_spectrum = np.array(result).mean(axis=0)
    plt.subplot(2, 1, 2)
    plt.plot(range(327, 941), mean_spectrum, label="Mean Spectrum", c="pink")
    plt.legend()
    plt.xlabel("Wavelength (nm)")
    plt.ylabel("Rrs (sr^-1)")

    df = pd.DataFrame({"Wavelength (nm)": range(327, 941),
                       "Rrs (sr^-1)": mean_spectrum})
    df.to_excel('./mean_spectrum.xlsx'.format(i), sheet_name='Spectrum', header=True, index=False)

    plt.show()


def sentinel_data_download(product_name_list, path="./Downloads"):
    '''
    Sentinel卫星影像数据下载，需要欧空局Copernicus Data Space Ecosystem账号
    :param product_name_list: 待下载影像名称列表
    :param path: 下载保存路径
    '''
    if not os.path.isdir(path):
        os.mkdir(path)

    # 欧空局Copernicus Data Space Ecosystem账号
    # https://dataspace.copernicus.eu/
    print("请输入欧空局Copernicus Data Space Ecosystem账号和密码，详见https://dataspace.copernicus.eu/")
    user_name = input("Enter the Username (Email): ")
    password = getpass.getpass("Enter the Password: ")

    # 若因网络问题下载失败则重新下载
    index = 0
    while index < len(product_name_list):
        name = product_name_list[index]
        instruction = "curl -s -X POST https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token -H \"Content-Type: application/x-www-form-urlencoded\" -d \"username={}\" -d \"password={}\" -d \"grant_type=password\" -d \"client_id=cdse-public\" > ./access_token.txt".format(user_name, password)
        os.system(instruction)
        with open("./access_token.txt") as f:
            result = json.loads(f.read())
        access_token = result["access_token"]
        os.system("del access_token.txt")

        result = requests.get(
            "https://catalogue.dataspace.copernicus.eu/odata/v1/Products?$filter=Name eq '" + name + "'").json()
        id = result['value'][0]["Id"]

        instruction = "curl -H \"Authorization: Bearer " + access_token + "\" \"https://catalogue.dataspace.copernicus.eu/odata/v1/Products(" + id + ")/$value\" --location-trusted --output " + os.path.join(path, "{}.zip".format(name.split(".")[0]))
        os.system(instruction)

        try:
            f = zipfile.ZipFile(os.path.join(path, "{}.zip".format(name.split(".")[0])), 'r')
            for file in f.namelist():
                f.extract(file, path)
            index += 1
        except:
            pass


def load_spectral_respones_function(type, filepath):
    '''
    读取Sentinel-2 MSI光谱响应函数(https://sentiwiki.copernicus.eu/web/s2-documents)，读取波长范围327nm - 940nm，包含B1、B2、B3、B4、B5、B6、B7、B8、B8A共9个波段
    :param type: 载荷名称(S2A, S2B, S2C三选一)
    :param filepath: 光谱响应函数文件路径
    :return spectra: 光谱响应函数(Numpy数组形式)
    '''
    if type == "S2A":
        spectra = pd.read_excel(filepath, sheet_name='Spectral Responses (S2A)')
        spectra = spectra.iloc[27: 641, 1: 10]
        spectra = spectra.values
        spectra = spectra.T
        return spectra
    elif type == "S2B":
        spectra = pd.read_excel(filepath, sheet_name='Spectral Responses (S2B)')
        spectra = spectra.iloc[27: 641, 1: 10]
        spectra = spectra.values
        spectra = spectra.T
        return spectra
    elif type == "S2C":
        spectra = pd.read_excel(filepath, sheet_name='Spectral Responses (S2C)')
        spectra = spectra.iloc[27: 641, 1: 10]
        spectra = spectra.values
        spectra = spectra.T
        return spectra
    else:
        return None
