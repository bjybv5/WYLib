from osgeo import gdal
import cv2


DTYPE2GDAL = {
    "uint8": gdal.GDT_Byte,
    "uint16": gdal.GDT_UInt16,
    "int16": gdal.GDT_Int16,
    "uint32": gdal.GDT_UInt32,
    "int32": gdal.GDT_Int32,
    "float32": gdal.GDT_Float32,
    "float64": gdal.GDT_Float64,
    "cint16": gdal.GDT_CInt16,
    "cint32": gdal.GDT_CInt32,
    "cfloat32": gdal.GDT_CFloat32,
    "cfloat64": gdal.GDT_CFloat64
}

RESAMPLE_METHODS = {
    "nearest": cv2.INTER_NEAREST,
    "bilinear": cv2.INTER_LINEAR,
    "bicubic": cv2.INTER_CUBIC,
    "area": cv2.INTER_AREA,
    "lanczos4": cv2.INTER_LANCZOS4,
    "linear_exact": cv2.INTER_LINEAR_EXACT,
    "nearest_exact": cv2.INTER_NEAREST_EXACT,
    "max": cv2.INTER_MAX,
    "warp_fill_outliers": cv2.WARP_FILL_OUTLIERS,
    "warp_inverse_map": cv2.WARP_INVERSE_MAP
}


