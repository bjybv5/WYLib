from osgeo import gdal
from osgeo import osr
import os
import shutil
import numpy as np
import cv2
import sys
from wylib.config import *


class Sentinel2Image(object):
    def __init__(self, image_dir):
        self.image_dir = image_dir
        self.band_count = 0
        self.RADIO_ADD_OFFSET = -1000

    def __del__(self):
        self.__dict__.clear()
