from osgeo import gdal
from osgeo import osr
import os
import shutil
import numpy as np
import cv2
import sys
from wylib.config import *
from wylib.utils import *


class RSImage(object):
    def __init__(self, image_file=None):
        '''
        初始化影像
        :param image_file: 影像路径
        '''
        self.image_file = image_file
        self.ds = None
        self.img_GeoTransform = None
        self.img_proj = None
        self.image_array = None
        self.column = None
        self.row = None
        self.band_count = None
        self.no_data_value = None
        self.dtype = None
        if self.image_file is not None:
            self.load_from_file()

    def load_from_file(self, image_file=None):
        '''
        从文件中读取影像
        :param image_file: 影像路径
        '''
        if image_file is not None:
            self.image_file = image_file
        self.ds = gdal.Open(self.image_file, 0)
        if self.ds is None:
            print("无法打开影像: {}".format(self.image_file))
            return
        self.img_GeoTransform = self.ds.GetGeoTransform()
        self.img_proj = self.ds.GetProjection()
        self.image_array = self.ds.ReadAsArray()
        self.column = self.ds.RasterXSize
        self.row = self.ds.RasterYSize
        self.band_count = self.ds.RasterCount
        self.no_data_value = self.ds.GetRasterBand(1).GetNoDataValue()
        self.dtype = self.image_array.dtype

    def save_as(self, target_file):
        '''
        保存影像至指定路径
        :param target_file: 影像输出路径
        '''
        type = target_file.split(".")[-1]
        if type  in ["dat", "img", "DAT", "IMG"]:
            driver = gdal.GetDriverByName("ENVI")
        elif type in ["tif", "tiff", "TIF", "TIFF"]:
            driver = gdal.GetDriverByName("GTiff")
        else:
            print("输出格式不支持")
            return

        if self.image_array is None:
            print("影像无数据")
            return
        else:
            if len(self.image_array.shape) == 3:
                self.band_count, self.row, self.column = self.image_array.shape
            elif len(self.image_array.shape) == 2:
                self.row, self.column = self.image_array.shape
                self.band_count = 1
            else:
                print("数据不符合保存要求")
                return

        self.dtype = self.image_array.dtype

        result_ds = driver.Create(target_file, self.column, self.row, self.band_count, DTYPE2GDAL[self.dtype.name])

        if self.img_GeoTransform is not None:
            result_ds.SetGeoTransform(self.img_GeoTransform)

        if self.img_proj is not None:
            result_ds.SetProjection(self.img_proj)

        if len(self.image_array.shape) == 3:
            for b in range(self.band_count):
                result_ds.GetRasterBand(b + 1).WriteArray(self.image_array[b, :, :])
                if self.no_data_value is not None:
                    result_ds.GetRasterBand(b + 1).SetNoDataValue(self.no_data_value)
        else:
            result_ds.GetRasterBand(1).WriteArray(self.image_array)
            if self.no_data_value is not None:
                result_ds.GetRasterBand(1).SetNoDataValue(self.no_data_value)

        del result_ds

    def resample(self, target_row, target_column, method="bicubic"):
        '''
        对自身重采样，更新相关属性
        :param target_row: 重采样目标行数
        :param target_column: 重采样目标列数
        :param method: 重采样方法
        '''
        if target_row <= 0 or target_column <= 0:
            print("目标尺寸无意义")
            return
        self.image_array = image_resize(self.image_array, target_row, target_column, interpolation_method=RESAMPLE_METHODS[method])
        geotrans = list(self.img_GeoTransform)
        scale_column = self.column / target_column
        scale_row = self.row / target_row
        geotrans[1] = geotrans[1] * scale_column
        geotrans[5] = geotrans[5] * scale_row
        self.img_GeoTransform = tuple(geotrans)
        self.column = target_column
        self.row = target_row

    def get_imagexy(self, lon, lat, sentinel_flag=False):
        '''
        根据经纬度获取影像行列号
        :param lon: 经度
        :param lat: 纬度
        :param sentinel_flag: 对于Sentinel-2原数据的坐标则需设置为True，否则为False
        :return x, y: 列下标、行下标
        '''
        if type(lon) == str:
            lon = position_transform_str2num(lon)
        if type(lat) == str:
            lat = position_transform_str2num(lat)
        if sentinel_flag:
            x, y = lonlat2imagexy_Sentinel(self.img_GeoTransform, self.img_proj, lon, lat)
        else:
            x, y = lonlat2imagexy(self.img_GeoTransform, self.img_proj, lon, lat)
        return x, y

    def get_lonlat(self, x, y, sentinel_flag=False):
        '''
        根据影像行列号获取经纬度
        :param x: 列下标
        :param y: 行下标
        :param sentinel_flag: 对于Sentinel-2原数据的坐标则需设置为True，否则为False
        :return lon, lat: 经度、纬度
        '''
        if sentinel_flag:
            lat, lon = imagexy2lonlat_Sentinel(self.img_GeoTransform, self.img_proj, x, y)
        else:
            lon, lat = imagexy2lonlat(self.img_GeoTransform, self.img_proj, x, y)
        return lon, lat

    def __del__(self):
        self.__dict__.clear()