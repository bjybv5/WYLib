import shutil
from esa_snappy import ProductIO
from esa_snappy import jpy
from esa_snappy import GPF
from tqdm import tqdm
import os
from osgeo import gdal
import numpy as np
from wylib.config import *


def C2RCC_process(product):
    HashMap = jpy.get_type('java.util.HashMap')
    parameters = HashMap()

    parameters.put('validPixelExpression', "B8 > 0 && B8 < 0.1")
    parameters.put('salinity', "35.0")
    parameters.put('temperature', "15.0")
    parameters.put('ozone', "330.0")
    parameters.put('press', "1000.0")
    parameters.put('elevation', "0.0")
    parameters.put('TSMfac', "1.06")
    parameters.put('TSMexp', "0.942")
    parameters.put('CHLexp', "1.04")
    parameters.put('CHLfac', "21.0")
    parameters.put('thresholdRtosaOOS', "0.05")
    parameters.put('thresholdAcReflecOos', "0.1")
    parameters.put('thresholdCloudTDown865', "0.955")
    parameters.put('netSet', "C2RCC-Nets")
    parameters.put('outputAsRrs', "false")
    parameters.put('deriveRwFromPathAndTransmittance', "false")
    parameters.put('useEcmwfAuxData', "false")

    return GPF.createProduct('C2RCC', parameters, product)


def resample_process(product, taget_resolution=10):
    HashMap = jpy.get_type('java.util.HashMap')
    parameters = HashMap()

    parameters.put('targetResolution', str(taget_resolution))
    parameters.put('upsampling', "Nearest")
    parameters.put('downsampling', "First")
    parameters.put('flagDownsampling', "First")
    parameters.put('resampleOnPyramidLevels', "true")

    return GPF.createProduct('Resample', parameters, product)


def batch_resample(input_path, output_path, taget_resolution=10):
    '''
    Snap批量重采样，输入目录中可放入若干景Senrinel-2 L1C影像
    :param input_path: 输入目录
    :param output_path: 输出目录
    :param taget_resolution: 目标空间分辨率，单位为米
    '''
    if os.path.isdir(output_path):
        shutil.rmtree(output_path)
    os.mkdir(output_path)

    base_path = input_path
    for image_path in tqdm(os.listdir(base_path)):
        image_name = image_path.split(".")[0]
        file_path = os.path.join(base_path, image_path, "MTD_MSIL1C.xml")
        product = ProductIO.readProduct(file_path)

        product_resampled = resample_process(product, taget_resolution=taget_resolution)

        ProductIO.writeProduct(product_resampled, os.path.join(output_path, './{}_resampled.dim'.format(image_name)), 'BEAM-DIMAP')


def batch_resample_C2RCC(input_path, output_path, taget_resolution=10):
    '''
    Snap批量重采样并C2RCC大气校正，输入目录中可放入若干景Senrinel-2 L1C影像
    :param input_path: 输入目录
    :param output_path: 输出目录
    :param taget_resolution: 目标空间分辨率，单位为米
    '''
    if os.path.isdir(output_path):
        shutil.rmtree(output_path)
    os.mkdir(output_path)

    base_path = input_path
    for image_path in tqdm(os.listdir(base_path)):
        image_name = image_path.split(".")[0]
        file_path = os.path.join(base_path, image_path, "MTD_MSIL1C.xml")
        product = ProductIO.readProduct(file_path)

        product_resampled = resample_process(product, taget_resolution=taget_resolution)
        product_resampled_C2RCC = C2RCC_process(product_resampled)

        ProductIO.writeProduct(product_resampled_C2RCC, os.path.join(output_path, './{}_resampled_C2RCC.dim'.format(image_name)), 'BEAM-DIMAP')


def batch_C2RCC(input_path, output_path):
    '''
    Snap批量C2RCC大气校正，输入目录中可放入若干Snap官方格式数据（dim文件及配套data目录）
    :param input_path: 输入目录
    :param output_path: 输出目录
    '''
    if os.path.isdir(output_path):
        shutil.rmtree(output_path)
    os.mkdir(output_path)

    base_path = input_path
    for image_path in tqdm(os.listdir(base_path)):
        if image_path.split(".")[-1] == "data":
            continue
        image_name = image_path.split(".")[0]
        file_path = os.path.join(base_path, image_path)

        product = ProductIO.readProduct(file_path)

        product_resampled_C2RCC = C2RCC_process(product)

        ProductIO.writeProduct(product_resampled_C2RCC, os.path.join(output_path, './{}_C2RCC.dim'.format(image_name)), 'BEAM-DIMAP')


def S2_resampled_edit(custom_image_file, resampled_dir):
    '''
    修改Snap生成的重采样影像数据内容
    :param custom_image_file: 自定义影像内容
    :param resampled_dir: 重采样影像目录
    '''
    custom_ds = gdal.Open(custom_image_file, 0)
    custom_image = custom_ds.ReadAsArray()

    band_names = ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B9", "B11", "B12"]
    for i in range(12):
        file_path = os.path.join(resampled_dir, "{}.img".format(band_names[i]))
        ds = gdal.Open(file_path, 1)
        band = ds.GetRasterBand(1)
        band.WriteArray(custom_image[i, :, :])

        del ds

    del custom_image, custom_ds


def band_stack_C2RCC(input_path, output_path):
    '''
    堆叠C2RCC大气校正结果波段，输入目录中可放入若干Snap官方格式数据（dim文件及配套data目录）
    :param input_path: 输入目录
    :param output_path: 输出目录
    '''
    if os.path.isdir(output_path):
        shutil.rmtree(output_path)
    os.mkdir(output_path)

    for image_path in tqdm(os.listdir(input_path)):
        if image_path.split(".")[-1] == "dim":
            continue
        temp_image = []
        band_names = ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8A"]
        # band_names = ["B1", "B2", "B3", "B4", "B5", "B6"]
        for i in range(8):
            file_path = os.path.join(input_path, image_path + "/rhow_{}.img".format(band_names[i]))
            ds = gdal.Open(file_path)
            temp_image.append(ds.ReadAsArray())
            if i == 0:
                img_GeoTransform = ds.GetGeoTransform()
                img_proj = ds.GetProjection()

            del ds

        temp_image = np.array(temp_image)

        driver = gdal.GetDriverByName("ENVI")
        result_ds = driver.Create(os.path.join(output_path, image_path.split(".")[0] + "_rhow.dat"),
                                  temp_image.shape[1], temp_image.shape[2], temp_image.shape[0], DTYPE2GDAL[temp_image.dtype.name])
        result_ds.SetGeoTransform(img_GeoTransform)
        result_ds.SetProjection(img_proj)

        for b in range(temp_image.shape[0]):
            band = result_ds.GetRasterBand(b + 1)
            band.WriteArray(temp_image[b, :, :])
            band.SetNoDataValue(0)

        del result_ds, temp_image

